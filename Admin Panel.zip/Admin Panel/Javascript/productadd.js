jQuery(document).ready(function () {
    ImgUpload();
   
  });
  
  function ImgUpload() {
    var imgWrap = "";
    var imgArray = [];
  
    $('.upload__inputfile').each(function () {
      $(this).on('change', function (e) {
        imgWrap = $(this).closest('.upload__box').find('.upload__img-wrap');
        var maxLength = $(this).attr('data-max_length');
  
        var files = e.target.files;
        var filesArr = Array.prototype.slice.call(files);
        var iterator = 0;
        filesArr.forEach(function (f, index) {
  
          if (!f.type.match('image.*')) {
            return;
          }
  
          if (imgArray.length > maxLength) {
            return false
          } else {
            var len = 0;
            for (var i = 0; i < imgArray.length; i++) {
              if (imgArray[i] !== undefined) {
                len++;
              }
            }
            if (len > maxLength) {
              return false;
            } else {
              imgArray.push(f);
  
              var reader = new FileReader();
              reader.onload = function (e) {
                var html = "<div class='upload__img-box'><div style='background-image: url(" + e.target.result + ")' data-number='" + $(".upload__img-close").length + "' data-file='" + f.name + "' class='img-bg'><div class='upload__img-close'></div></div></div>";
                imgWrap.append(html);
                iterator++;
              }
              reader.readAsDataURL(f);
            }
          }
        });
      });
    });
  
    $('body').on('click', ".upload__img-close", function (e) {
        
      var file = $(this).parent().data("file");
      console.log(file);

      //var file = document.getElementsByName("image[]");
      //console.log(file);
      //file.value = "";
      
      for (var i = 0; i < imgArray.length; i++) {
        if (imgArray[i].name === file) {
          imgArray.splice(i, 1);

          console.log(file);
         
          break;
        }
      }
      $(this).parent().parent().remove();
   
      console.log(file);
         
   
    });
    console.log(file);
  }



  window.onload = function() {
    (function(){
     var col_element, next_element, cursorStart = 0, dragStart = false, width, height, th_width, next_width = undefined, next_height, resize, resize_left, table_wt, resizeCheck;
     var container = document.getElementById("container"),
         table = document.getElementById("table_resize"),
         table_th = table.getElementsByTagName("th"),
         bodyRect = document.body.getBoundingClientRect()
 
      container.style.position = "relative";
 
     function mouseDown(){
       resize = this;
       resizeCheck = resize.classList.contains("y_resize");
       var col_index = parseInt(resize.getAttribute("data-resizecol"))-1;
       col_element = table_th[col_index];
       next_element = table_th[col_index+1];
       dragStart = true;
       cursorStart = (resizeCheck)?event.pageX:event.pageY;
       var elm_bound = col_element.getBoundingClientRect();
       width = elm_bound.width;
       table_wt =table.offsetWidth;
       if(next_element != undefined){
         var next_bound = next_element.getBoundingClientRect();
         next_width = next_bound.width;
       }
       resize_left = (this.getBoundingClientRect()).left - bodyRect.left;
     }
     function mouseMove(){
       if(dragStart){
         var cursorPosition = (resizeCheck)?event.pageX:event.pageY;
         var mouseMoved = (cursorPosition - cursorStart);
         var newLeft = resize_left + mouseMoved;
         var newWidth = width + mouseMoved;
         var new_nextWidth, new_nextHeight;
         if(next_element != undefined){
           new_nextWidth = next_width - mouseMoved;
         }
         if(newWidth > 30 && (new_nextWidth > 30 || next_element == undefined)){
           col_element.style.cssText = "width: "+newWidth+"px;";
           if(next_element != undefined){
             next_element.style.cssText = "width: "+new_nextWidth+"px";
           }
           else{
             table.style.width = (table_wt + mouseMoved)+"px";
           }
           resize.style.cssText = "left: "+newLeft+"px;";
         }
       }
     }
     function mouseUp(){
       if(dragStart){
          dragStart = false;
       }
     }
     function initEvents(table_th){ 
       var tb_resize = container.getElementsByClassName("tb_resize");
       var th_length = table_th.length;
       for(var i = 0; i<th_length; i++){
         document.body.addEventListener("mousemove", mouseMove);
         tb_resize[i].addEventListener("mousedown", mouseDown);
         tb_resize[i].addEventListener("mouseup", mouseUp);
         table_th[i].style.width = th_width+"px";
       }
     } 
     function setTdWidth(){
       var elm_bound = table.getBoundingClientRect();
       var table_wt = elm_bound.width;
       var th_length = table_th.length;
       th_width = table_wt/th_length;
     }
     function createResizeDiv(){
       var cont = document.getElementById("container"); 
       var th_length = table_th.length;
       for(var i=1; i<=th_length; i++){
         var yDiv = document.createElement("div");
         yDiv.className = "y_resize tb_resize";
         yDiv.setAttribute("data-resizecol",i);
         var leftPos = (i*th_width)+0.5;
         yDiv.style.cssText = "left: "+leftPos+"px;";
         cont.append(yDiv);
       }
     }
      
      
     setTdWidth(table);
     createResizeDiv();
     initEvents(table_th);
   })();
 }